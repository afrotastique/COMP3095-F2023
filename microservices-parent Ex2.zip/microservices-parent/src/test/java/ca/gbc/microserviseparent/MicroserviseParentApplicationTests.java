package ca.gbc.microserviseparent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviseParentApplicationTests {

	@Test
	void contextLoads() {
	}

}
